/* Comprueba que MAP_PRIVATE no modifica el archivo de prueba. */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    int fd;
    struct stat info;
    char original;
    char *mapping;
    char after;

    if (argc != 2) {
        fprintf(stderr, "Uso: %s <archivo-temporal>\n", argv[0]);
        return 2;
    }

    fd = open(argv[1], O_RDONLY);
    if (fd < 0 || fstat(fd, &info) != 0 || info.st_size == 0) {
        perror("open/fstat");
        return 1;
    }

    if (pread(fd, &original, 1, 0) != 1) {
        perror("pread");
        close(fd);
        return 1;
    }

    mapping = mmap(NULL, info.st_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (mapping == MAP_FAILED) {
        perror("mmap");
        close(fd);
        return 1;
    }
    mapping[0] = 'X';
    munmap(mapping, info.st_size);

    if (pread(fd, &after, 1, 0) != 1) {
        perror("pread");
        close(fd);
        return 1;
    }
    close(fd);

    if (after == original) {
        puts("PASS: MAP_PRIVATE no modificó el archivo.");
        return 0;
    }
    puts("FAIL: el archivo cambió.");
    return 1;
}
