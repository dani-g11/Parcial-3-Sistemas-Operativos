#!/usr/bin/env bash
# Ejecutar desde WSL como un usuario normal con sudo disponible.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BIN="$ROOT_DIR/.output"
RESULTS="$ROOT_DIR/results"
FILE="$RESULTS/protected_file.txt"
LOADER_PID=""

cleanup() {
    if [[ -n "$LOADER_PID" ]]; then
        sudo kill "$LOADER_PID" 2>/dev/null || true
        wait "$LOADER_PID" 2>/dev/null || true
    fi
}
trap cleanup EXIT

mkdir -p "$RESULTS"
printf 'archivo de prueba para mmap\n' > "$FILE"
"$BIN/private_write_baseline" "$FILE"

# Primera ejecución: el usuario actual no está en la allowlist.
sudo "$BIN/mmap_loader" --protect "$FILE" > "$RESULTS/loader_denied.log" 2>&1 &
LOADER_PID=$!
sleep 1
"$BIN/mmap_cases" "$FILE" ro_shared ok
"$BIN/mmap_cases" "$FILE" rw_shared deny
"$BIN/mmap_cases" "$FILE" rw_private ok
"$BIN/mmap_cases" "$FILE" exec deny
cleanup
LOADER_PID=""

# Segunda ejecución: R3 permite todas las operaciones del UID autorizado.
sudo "$BIN/mmap_loader" --protect "$FILE" --allow-uid "$(id -u)" > "$RESULTS/loader_allowed.log" 2>&1 &
LOADER_PID=$!
sleep 1
"$BIN/mmap_cases" "$FILE" rw_shared ok
"$BIN/mmap_cases" "$FILE" exec ok

echo "PASS: pruebas completadas. Revise $RESULTS/*.log para eventos de auditoria."
