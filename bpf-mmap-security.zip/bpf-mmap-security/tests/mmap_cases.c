#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

static void usage(const char *program)
{
    fprintf(stderr, "Uso: %s <archivo> <ro_shared|rw_shared|rw_private|exec> <ok|deny>\n", program);
}

int main(int argc, char **argv)
{
    int fd;
    int prot = PROT_READ;
    int flags = MAP_SHARED;
    int should_succeed;
    struct stat info;
    void *mapping;
    int success;

    if (argc != 4) {
        usage(argv[0]);
        return 2;
    }

    if (strcmp(argv[2], "rw_shared") == 0)
        prot |= PROT_WRITE;
    else if (strcmp(argv[2], "rw_private") == 0) {
        prot |= PROT_WRITE;
        flags = MAP_PRIVATE;
    } else if (strcmp(argv[2], "exec") == 0)
        prot |= PROT_EXEC;
    else if (strcmp(argv[2], "ro_shared") != 0) {
        usage(argv[0]);
        return 2;
    }

    if (strcmp(argv[3], "ok") == 0)
        should_succeed = 1;
    else if (strcmp(argv[3], "deny") == 0)
        should_succeed = 0;
    else {
        usage(argv[0]);
        return 2;
    }

    fd = open(argv[1], (prot & PROT_WRITE) && flags == MAP_SHARED ? O_RDWR : O_RDONLY);
    if (fd < 0 || fstat(fd, &info) != 0) {
        perror("open/fstat");
        return 1;
    }

    mapping = mmap(NULL, info.st_size, prot, flags, fd, 0);
    success = mapping != MAP_FAILED;
    if (success)
        munmap(mapping, info.st_size);
    else
        fprintf(stderr, "mmap: %s\n", strerror(errno));
    close(fd);

    if (success == should_succeed) {
        printf("PASS: %s fue %s\n", argv[2], success ? "permitido" : "denegado");
        return 0;
    }

    printf("FAIL: %s fue %s y se esperaba %s\n", argv[2],
           success ? "permitido" : "denegado", should_succeed ? "permitido" : "denegado");
    return 1;
}
