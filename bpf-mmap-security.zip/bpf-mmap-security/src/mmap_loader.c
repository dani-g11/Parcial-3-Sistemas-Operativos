#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <unistd.h>

#include <bpf/bpf.h>
#include <bpf/libbpf.h>
#include "mmap_lsm.h"
#include "mmap_lsm.skel.h"

static volatile sig_atomic_t keep_running = 1;

static void stop_loader(int signal_number)
{
    (void)signal_number;
    keep_running = 0;
}

static const char *reason_text(__u32 reason)
{
    switch (reason) {
    case MMAP_REASON_SHARED_WRITE:
        return "MAP_SHARED con PROT_WRITE";
    case MMAP_REASON_EXEC:
        return "PROT_EXEC";
    case MMAP_REASON_ALLOWLIST:
        return "UID en allowlist";
    default:
        return "permitido por la politica";
    }
}

static int show_event(void *context, void *data, size_t size)
{
    const struct mmap_event *event = data;
    (void)context;

    if (size != sizeof(*event))
        return 0;

    printf("pid=%u uid=%u inode=%llu decision=%s motivo=%s\n",
           event->pid, event->uid, (unsigned long long)event->inode,
           event->decision ? "DENEGAR" : "PERMITIR", reason_text(event->reason));
    return 0;
}

static int add_protected_file(struct mmap_lsm_bpf *skeleton, const char *path)
{
    struct stat info;
    struct protected_file_key key = {};
    __u8 value = 1;
    int map_fd;

    if (stat(path, &info) != 0) {
        fprintf(stderr, "No se puede consultar %s: %s\n", path, strerror(errno));
        return -1;
    }

    key.device = (unsigned int)info.st_dev;
    key.inode = (unsigned long long)info.st_ino;
    map_fd = bpf_map__fd(skeleton->maps.protected_files);
    if (bpf_map_update_elem(map_fd, &key, &value, BPF_ANY) != 0) {
        fprintf(stderr, "No se pudo proteger %s: %s\n", path, strerror(errno));
        return -1;
    }

    printf("Protegido: %s (device=%u, inode=%llu)\n", path, key.device,
           (unsigned long long)key.inode);
    return 0;
}

static int add_allowed_uid(struct mmap_lsm_bpf *skeleton, const char *text_uid)
{
    char *end;
    unsigned long parsed_uid;
    __u32 uid;
    __u8 value = 1;
    int map_fd;

    errno = 0;
    parsed_uid = strtoul(text_uid, &end, 10);
    if (errno || *end != '\0' || parsed_uid > UINT_MAX) {
        fprintf(stderr, "UID invalido: %s\n", text_uid);
        return -1;
    }

    uid = (__u32)parsed_uid;
    map_fd = bpf_map__fd(skeleton->maps.allowed_uids);
    if (bpf_map_update_elem(map_fd, &uid, &value, BPF_ANY) != 0) {
        fprintf(stderr, "No se pudo agregar el UID %u: %s\n", uid, strerror(errno));
        return -1;
    }
    printf("Allowlist: UID %u\n", uid);
    return 0;
}

static void usage(const char *program)
{
    fprintf(stderr, "Uso: %s --protect ARCHIVO [--allow-uid UID]...\n", program);
}

int main(int argc, char **argv)
{
    struct mmap_lsm_bpf *skeleton = NULL;
    struct ring_buffer *ring_buffer = NULL;
    struct bpf_link *link = NULL;
    int protected_count = 0;
    int index;
    int result = 1;

    libbpf_set_strict_mode(LIBBPF_STRICT_ALL);
    for (index = 1; index < argc; index++) {
        if (strcmp(argv[index], "--protect") == 0) {
            if (++index == argc) {
                usage(argv[0]);
                return 2;
            }
            protected_count++;
        } else if (strcmp(argv[index], "--allow-uid") == 0) {
            if (++index == argc) {
                usage(argv[0]);
                return 2;
            }
        } else {
            usage(argv[0]);
            return 2;
        }
    }
    if (!protected_count) {
        usage(argv[0]);
        return 2;
    }

    skeleton = mmap_lsm_bpf__open();
    if (!skeleton || mmap_lsm_bpf__load(skeleton)) {
        fprintf(stderr, "No se pudo cargar BPF-LSM. Ejecute como root y revise BPF-LSM.\n");
        goto cleanup;
    }

    for (index = 1; index < argc; index++) {
        if (strcmp(argv[index], "--protect") == 0) {
            if (add_protected_file(skeleton, argv[++index]))
                goto cleanup;
        } else if (strcmp(argv[index], "--allow-uid") == 0) {
            if (add_allowed_uid(skeleton, argv[++index]))
                goto cleanup;
        }
    }

    link = bpf_program__attach_lsm(skeleton->progs.check_mmap_file);
    if (!link) {
        fprintf(stderr, "No se pudo adjuntar al hook mmap_file: %s\n", strerror(errno));
        goto cleanup;
    }

    ring_buffer = ring_buffer__new(bpf_map__fd(skeleton->maps.events), show_event, NULL, NULL);
    if (!ring_buffer) {
        fprintf(stderr, "No se pudo crear el lector de eventos.\n");
        goto cleanup;
    }

    signal(SIGINT, stop_loader);
    signal(SIGTERM, stop_loader);
    puts("BPF-LSM activo. Presione Ctrl+C para desmontarlo.");
    while (keep_running) {
        int poll_result = ring_buffer__poll(ring_buffer, 250);
        if (poll_result < 0 && poll_result != -EINTR) {
            fprintf(stderr, "Error leyendo eventos: %d\n", poll_result);
            goto cleanup;
        }
    }
    result = 0;

cleanup:
    ring_buffer__free(ring_buffer);
    bpf_link__destroy(link);
    mmap_lsm_bpf__destroy(skeleton);
    return result;
}
