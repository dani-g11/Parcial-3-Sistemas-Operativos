#ifndef MMAP_LSM_H
#define MMAP_LSM_H

/* vmlinux.h ya define estos tipos para el programa BPF. */
#ifndef __BPF__
#include <linux/types.h>
#endif

/* Motivos simples para mostrar en el cargador. */
#define MMAP_REASON_ALLOWED 0
#define MMAP_REASON_SHARED_WRITE 1
#define MMAP_REASON_EXEC 2
#define MMAP_REASON_ALLOWLIST 3

/* El archivo se identifica por el dispositivo y el inodo. */
struct protected_file_key {
    __u32 device;
    __u64 inode;
};

/* Evento mínimo enviado desde BPF al cargador. */
struct mmap_event {
    __u32 pid;
    __u32 uid;
    __u32 device;
    __u32 decision; /* 0 permite, 1 niega */
    __u64 inode;
    __u64 prot;
    __u64 flags;
    __u32 reason;
};

#endif
