/*
 * Programa BPF-LSM para el hook mmap_file.
 * Solo aplica las reglas R1-R3 del parcial.
 */
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>
#include "mmap_lsm.h"

/* Evita headers de arquitectura al compilar con clang -target bpf. */
#define MMAP_PROT_WRITE 0x2
#define MMAP_PROT_EXEC  0x4
#define MMAP_SHARED     0x01
#define MMAP_EACCES     13

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 128);
    __type(key, struct protected_file_key);
    __type(value, __u8);
} protected_files SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 128);
    __type(key, __u32);
    __type(value, __u8);
} allowed_uids SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} events SEC(".maps");

static __always_inline void send_event(struct file *file, unsigned long prot,
                                       unsigned long flags, __u32 decision,
                                       __u32 reason)
{
    struct mmap_event *event;
    struct inode *inode;

    event = bpf_ringbuf_reserve(&events, sizeof(*event), 0);
    if (!event)
        return;

    inode = BPF_CORE_READ(file, f_inode);
    event->pid = bpf_get_current_pid_tgid() >> 32;
    event->uid = (__u32)bpf_get_current_uid_gid();
    event->device = BPF_CORE_READ(inode, i_sb, s_dev);
    event->inode = BPF_CORE_READ(inode, i_ino);
    event->prot = prot;
    event->flags = flags;
    event->decision = decision;
    event->reason = reason;
    bpf_ringbuf_submit(event, 0);
}

/*
 * Firma comprobada contra el BTF del kernel de prueba:
 * mmap_file(struct file *, unsigned long reqprot, unsigned long prot,
 *           unsigned long flags).
 */
SEC("lsm/mmap_file")
int BPF_PROG(check_mmap_file, struct file *file, unsigned long reqprot,
             unsigned long prot, unsigned long flags)
{
    struct protected_file_key key = {};
    struct inode *inode;
    __u32 uid;

    (void)reqprot;
    inode = BPF_CORE_READ(file, f_inode);
    key.device = BPF_CORE_READ(inode, i_sb, s_dev);
    key.inode = BPF_CORE_READ(inode, i_ino);

    if (!bpf_map_lookup_elem(&protected_files, &key))
        return 0;

    uid = (__u32)bpf_get_current_uid_gid();
    if (bpf_map_lookup_elem(&allowed_uids, &uid)) {
        send_event(file, prot, flags, 0, MMAP_REASON_ALLOWLIST);
        return 0;
    }

    if ((flags & MMAP_SHARED) && (prot & MMAP_PROT_WRITE)) {
        send_event(file, prot, flags, 1, MMAP_REASON_SHARED_WRITE);
        return -MMAP_EACCES;
    }

    if (prot & MMAP_PROT_EXEC) {
        send_event(file, prot, flags, 1, MMAP_REASON_EXEC);
        return -MMAP_EACCES;
    }

    send_event(file, prot, flags, 0, MMAP_REASON_ALLOWED);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
