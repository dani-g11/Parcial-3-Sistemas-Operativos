# Seguridad de archivos con BPF-LSM y `mmap()`

 Parte III del parcial. El programa se conecta al hook LSM `mmap_file`; no modifica la System Call Table ni usa kprobes como mecanismo de bloqueo.

## Política implementada

Los archivos protegidos se identifican por el par `(st_dev, st_ino)`.

- **R1:** el cargador añade al mapa `protected_files` cada archivo pasado con `--protect`.
- **R2:** para esos archivos, el hook niega `MAP_SHARED` junto con `PROT_WRITE`, y cualquier mapeo que solicite `PROT_EXEC`.
- **R3:** un UID incluido con `--allow-uid` queda exceptuado de **ambas** denegaciones. Cada acceso a un archivo protegido genera un evento sencillo por ring buffer.

`MAP_PRIVATE | PROT_WRITE` se permite para un UID no autorizado. Este mapeo usa Copy-On-Write, por lo que una escritura no modifica directamente el archivo respaldado.

## Archivos

- `src/mmap_lsm.bpf.c`: programa BPF-LSM CO-RE.
- `src/mmap_loader.c`: carga el objeto, configura mapas, adjunta el hook y muestra auditoría.
- `src/mmap_lsm.h`: claves, eventos y motivos compartidos.
- `tests/mmap_cases.c`: prueba los cuatro tipos de mapeo requeridos.
- `tests/private_write_baseline.c`: prueba aislada de que `MAP_PRIVATE` no modifica el archivo. No es una PoC de explotación.
- `tests/run_tests.sh`: automatiza casos autorizados y no autorizados.

## Qué subir a GitHub

Sí: puedes subir el proyecto **sin** `.output/`. GitHub debe contener solamente los archivos que una persona puede leer, estudiar y regenerar:

```text
bpf-mmap-security/
├── .gitignore
├── Makefile
├── README.md
├── src/
│   ├── mmap_lsm.bpf.c
│   ├── mmap_loader.c
│   └── mmap_lsm.h
├── tests/
│   ├── mmap_cases.c
│   ├── private_write_baseline.c
│   └── run_tests.sh
└── results/
    └── .gitkeep
```

`.gitignore` excluye `.output/`, los logs y el archivo temporal de las pruebas. Esos archivos se regeneran o se crean al ejecutar el proyecto.

## Archivos que debes estudiar

La implementación que debes entender está en `src/`, `tests/`, `Makefile` y este README. No necesitas leer `.output/`.

- `src/mmap_lsm.bpf.c`: contiene las tres reglas R1-R3. Es el programa que el kernel ejecuta en el hook `mmap_file`.
- `src/mmap_loader.c`: es el programa normal de usuario. Carga BPF, marca el archivo protegido, añade UID a la allowlist y muestra eventos.
- `src/mmap_lsm.h`: define las estructuras pequeñas compartidas por ambos programas.
- `tests/mmap_cases.c`: intenta los distintos `mmap()` y muestra `PASS` o `FAIL`.
- `tests/private_write_baseline.c`: demuestra Copy-On-Write con `MAP_PRIVATE` sin explotar ninguna vulnerabilidad.
- `tests/run_tests.sh`: ejecuta los casos automáticamente.
- `Makefile`: explica cómo se compila todo con un solo comando.

### Por qué aparece `.output/`

`.output/` es una carpeta temporal de compilación. No contiene código que hayas escrito manualmente:

- `vmlinux.h`: archivo muy grande generado desde el BTF del kernel. Declara miles de tipos del kernel, aunque este proyecto usa solamente unos pocos. Es necesario al compilar BPF con CO-RE, pero no se estudia ni se sube a GitHub.
- `mmap_lsm.bpf.o`: versión compilada del programa BPF. Es un binario ELF, no un archivo de texto.
- `mmap_lsm.skel.h`: archivo generado por `bpftool` para que el cargador pueda abrir el objeto BPF.
- `mmap_loader`, `mmap_cases` y `private_write_baseline`: ejecutables compilados desde los archivos C.

Puedes borrarla con `make clean`. Cuando se necesite compilar otra vez, `make build` la crea de nuevo.

## Dependencias

Ejecutar en Linux o WSL2, no directamente en Windows:

```bash
sudo apt install build-essential clang llvm bpftool libbpf-dev libelf-dev zlib1g-dev
```

Además se requiere:

```bash
uname -r
ls -l /sys/kernel/btf/vmlinux
sudo bpftool feature probe kernel
cat /sys/kernel/security/lsm
```

El kernel debe tener BTF, BPF y BPF-LSM activos. Para adjuntar el programa se requieren privilegios suficientes, normalmente mediante `sudo`.

## Compilación

Desde WSL, entre a la carpeta del proyecto y ejecute:

```bash
make clean
make build
```

El Makefile genera `.output/vmlinux.h` desde el BTF del kernel en uso, compila el programa con `clang -target bpf`, crea el skeleton mediante `bpftool` y enlaza el cargador con libbpf. El objetivo usa `-Wall -Wextra -Werror` para el código de usuario.

## Ejecución manual

Crear un archivo de prueba que no sea importante:

```bash
mkdir -p results
printf 'archivo de prueba\n' > results/protected_file.txt
sudo ./.output/mmap_loader --protect results/protected_file.txt
```

En otra terminal, como el usuario normal que no está en la allowlist:

```bash
./.output/mmap_cases results/protected_file.txt ro_shared ok
./.output/mmap_cases results/protected_file.txt rw_shared deny
./.output/mmap_cases results/protected_file.txt rw_private ok
./.output/mmap_cases results/protected_file.txt exec deny
```

Para habilitar la excepción total R3, detener el cargador y arrancarlo así:

```bash
sudo ./.output/mmap_loader --protect results/protected_file.txt --allow-uid "$(id -u)"
```

Con ese UID, `rw_shared` y `exec` deben ser permitidos y auditados con el motivo `UID en allowlist`.

## Ejecución automática

```bash
make test
```

El script imprime `PASS` o `FAIL`, guarda las salidas de auditoría en `results/loader_denied.log` y `results/loader_allowed.log`, y solo escribe en `results/protected_file.txt`.

## Medición opcional

Con el cargador activo e inactivo se puede comparar el coste del caso permitido:

```bash
strace -c ./.output/mmap_cases results/protected_file.txt ro_shared ok
perf stat -e page-faults ./.output/mmap_cases results/protected_file.txt ro_shared ok
```

Registrar ambos resultados, el kernel (`uname -r`) y el número de iteraciones en el informe. `perf` puede requerir permisos adicionales en WSL.

## Limitaciones verificadas en este workspace

El entorno detectado usa WSL2 con kernel `6.18.33.2-microsoft-standard-WSL2`, BTF disponible, clang 21.1.8, bpftool 7.7.0 y libbpf 1.6.3. El BTF contiene `mmap_file` y `security_mmap_file`. Sin embargo, el usuario actual no tiene `CAP_SYS_ADMIN`, `CAP_BPF`, `CAP_NET_ADMIN` y `CAP_PERFMON`, por lo que el sondeo completo y la carga no se ejecutaron durante la creación de estos archivos.

Por esa razón, este README no afirma que el programa haya sido adjuntado ni que los casos se hayan ejecutado. Antes de entregar, ejecutar `make build`, `make test` y las mediciones en la instancia WSL con `sudo`; adjuntar los logs reales al informe.
